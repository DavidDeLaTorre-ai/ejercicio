Twittetr4J is a Twitter API binding library for the Java language licensed under the Apache License 2.0.

optional component adds Apache HttpClient support